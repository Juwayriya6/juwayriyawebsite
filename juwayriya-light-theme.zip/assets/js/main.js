/* ============ helpers ============ */
const qs  = (s, el=document)=>el.querySelector(s);
const qsa = (s, el=document)=>[...el.querySelectorAll(s)];

/* Year */
(() => { const y = qs('#year'); if (y) y.textContent = new Date().getFullYear(); })();

/* Smooth anchors */
qsa('a[href^="#"]').forEach(a=>{
  a.addEventListener('click', (e)=>{
    const id = a.getAttribute('href').slice(1);
    const el = qs(`#${id}`);
    if(!el) return;
    e.preventDefault();
    el.scrollIntoView({behavior:'smooth', block:'start'});
  });
});

/* --------------------- Hero slideshow --------------------- */
(function(){
  const hero = qs('#hero');
  if(!hero) return;

  const slides = JSON.parse(hero.getAttribute('data-slides') || '[]');
  if(!slides.length) return;

  // Make ::before read a CSS var
  const style = document.createElement('style');
  style.textContent = `#hero::before{ background-image: var(--bg) }`;
  document.head.appendChild(style);

  const dots = qs('.navdots');
  slides.forEach((_, idx)=>{
    const b = document.createElement('button');
    b.type = 'button';
    b.setAttribute('aria-label', `Go to slide ${idx+1}`);
    b.addEventListener('click', ()=>{ i=idx; set(true); });
    dots.appendChild(b);
  });

  let i = 0;
  function set(jump){
    const s = slides[i];
    hero.style.setProperty('--bg', `url('${s.src}')`);
    hero.style.setProperty('--bg-pos', s.pos || 'center center');
    qsa('.navdots button').forEach((b,idx)=> b.setAttribute('aria-current', idx===i ? 'true' : 'false'));
    if(!jump) i = (i+1) % slides.length;
  }

  set(true);
  setInterval(()=>set(false), 6000);
})();

/* --------------------- Lightbox (Poptrox) --------------------- */
(function(){
  // Home gallery
  const gallery = qs('.gallery .grid');
  if(gallery && window.jQuery && jQuery.fn.poptrox){
    jQuery(gallery).poptrox({
      overlayColor:'#000',
      overlayOpacity:0.85,
      usePopupCaption:true,
      caption: function($a){
        try{
          const meta = JSON.parse($a.attr('data-caption') || '{}');
          const title = meta.title ? `<strong>${meta.title}</strong>` : '';
          const text  = meta.text  ? `<div>${meta.text}</div>` : '';
          return `${title}${text}`;
        }catch(e){ return ''; }
      }
    });
  }

  // Collections page
  const grid = document.getElementById('collections-grid');
  if(grid && window.jQuery && jQuery.fn.poptrox){
    jQuery(grid).poptrox({
      overlayColor:'#000',
      overlayOpacity:0.85,
      usePopupCaption:true,
      caption: function($a){
        try{
          const meta = JSON.parse($a.attr('data-caption') || '{}');
          const title = meta.title ? `<strong>${meta.title}</strong>` : '';
          const text  = meta.text  ? `<div>${meta.text}</div>` : '';
          return `${title}${text}`;
        }catch(e){ return ''; }
      }
    });
  }
})();

/* --------------------- Collections filters --------------------- */
(function(){
  const grid = qs('#collections-grid');
  if(!grid) return;

  const chips = qsa('.filters .chip');
  const items = qsa('li', grid);

  function apply(filter){
    items.forEach(li=>{
      const match = filter==='all' || li.dataset.collection===filter;
      li.classList.toggle('hidden', !match);
    });
    chips.forEach(c=>c.classList.toggle('is-active', c.dataset.filter===filter));
  }

  chips.forEach(c=>{
    c.addEventListener('click', ()=>{
      const f = c.dataset.filter || 'all';
      history.replaceState(null, '', f==='all' ? location.pathname : `#${f}`);
      apply(f);
    });
  });

  // Deep-link support: collections.html#astronomy
  const start = location.hash.replace('#','') || 'all';
  apply(start);
})();