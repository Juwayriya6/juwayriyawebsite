# Juwayriya Light Monet/Xianxia Theme
This zip contains the rewritten files:
- index.html
- about.html
- collections.html
- assets/css/main.css
- assets/js/main.js

Note: Add vendor scripts if you want the lightbox to work:
- assets/js/jquery.min.js
- assets/js/poptrox.min.js

Created: 2025-10-28T06:26:48.291577
